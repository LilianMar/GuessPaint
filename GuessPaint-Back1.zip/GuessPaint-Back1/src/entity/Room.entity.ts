import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    BaseEntity,
    JoinColumn,
    ManyToOne
    } from "typeorm";
import { Category } from "./Category.entity";

    @Entity({ name: "rooms" })
    export class Room extends BaseEntity {
        @PrimaryGeneratedColumn("uuid")
        id: string;

        @Column({name: 'title', type: 'varchar',  nullable: false })
        title: string;

        @Column({name: 'progress', type: 'varchar', default: 'Sin iniciar', nullable: false})
        progress: string;  

        @Column({name: "category_id" , nullable: false})
        categoryId: string;

        @ManyToOne(() => Category, {nullable: false})
        @JoinColumn({ name: "category_id"})
        categories?: Category[];

        
    }