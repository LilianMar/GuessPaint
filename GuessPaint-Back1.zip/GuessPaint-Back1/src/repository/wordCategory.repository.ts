import { AppDataSource } from "../data-source";
import { WordCategory } from "../entity/WordCategory.entity";

export class WordCategoryRepository{
    private repository = AppDataSource.getRepository(WordCategory);
    


    async findById(id: string) {    
        return this.repository.findOneBy({ id });
    }

    async getAll() {
        return this.repository.find();
    }

    async save(wordCategory: WordCategory){
        return this.repository.save(wordCategory);
    }

    async update(wordCategory: WordCategory){
        return this.repository.update(wordCategory.id, wordCategory);
    }

    async delete(id: string){
        return this.repository.delete(id);
    }
}
