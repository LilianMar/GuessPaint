import { WordCategoryRepository } from "../repository/wordCategory.repository";
import { WordCategory } from "../entity/WordCategory.entity";
import { WordRepository } from "../repository/word.repository";
import { CategoryRepository } from "../repository/category.repository";
import { v4 as uuidv4 } from 'uuid';

export class WordCategoryService {
    private wordCategoryRepository: WordCategoryRepository = new WordCategoryRepository();
    private wordRepository: WordRepository = new WordRepository();
    private categoryRepository: CategoryRepository = new CategoryRepository();

    public async findById(id: string): Promise<WordCategory | undefined> {
        const wordCategory = await this.wordCategoryRepository.findById(id);
        return wordCategory;
    }

    public async getAll(): Promise<WordCategory[]> {
        return await this.wordCategoryRepository.getAll();
    }

    public async save(body: any) {
        const id = uuidv4();
        body['id'] = id;
        body['wordId'] = body.word_id;
        body['categoryId'] = body.category_id;
        const responseByIdWord = await this.wordRepository.findById(body.word_id);
        const responseByIdCategory = await this.categoryRepository.findById(body.category_id);

        if(!responseByIdWord || !responseByIdCategory){
            throw new Error('Word or Category not found');
        }
        return await this.wordCategoryRepository.save(body);
    }

    public async update(id: string, word_id: string, category_id: string): Promise<void>{
        const word= await this.wordRepository.findById(word_id);
        const category = await this.categoryRepository.findById(id);
        const wordCategory = await this.wordCategoryRepository.findById(id);

        if (!category || !word) {
            throw new Error('Category or Word not found');
        }
        if (!wordCategory) {
            throw new Error('WordCategory not found');
        }
        wordCategory.wordId = word_id;
        wordCategory.categoryId = category_id;
        await this.wordCategoryRepository.update(wordCategory);
    }

    public async delete(id: string) {
        return await this.wordCategoryRepository.delete(id);
    }

}
