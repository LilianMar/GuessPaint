export class WordResponse{
    id: string;
    texto: string;
}