export class CategoryResponse{
    id: string;
    title: string;
}