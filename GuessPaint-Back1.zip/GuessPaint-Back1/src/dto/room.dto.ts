export class RoomResponse{
    id: string;
    title: string;
    category_id: string;
    progress: string;
    
}