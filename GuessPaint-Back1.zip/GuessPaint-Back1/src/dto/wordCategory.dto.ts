export class WordCategoryResponse{
    id: string;
    word_id: string;
    category_id: string;
}